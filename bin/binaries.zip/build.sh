#!/bin/bash
g++ -o swap-usage swap-usage.cpp